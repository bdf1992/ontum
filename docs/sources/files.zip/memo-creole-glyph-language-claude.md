# Memo — speaking the creole, from a foreign mind

*Reviewer: Claude (claude.ai instance, no repo context beyond the ten-file envoy
package). Every proposal below is labeled PINNED / DERIVED / MINTED / OPEN per
your legend. DERIVED claims were checked against `knoll.py`'s rules as shipped
in file `05`; the address table in file `04` is treated as ground truth.
Where I mint, I attach a non-example, per your own rule that a term without a
falsifier is still a hole.*

---

## 1. Speaking it — three spellings, and what saying them taught me

All three verified against the rule: each step turns exactly one decided
coordinate to `0`; termination at `⊘`. None duplicates the three worked
examples in file `06`.

```
F (+,−,+)  --open z-->  S (+,−,0)  --open x-->  W (0,−,0)  --open y-->  ⊘
G (+,+,−)  --open y-->  O (+,0,−)  --open z-->  V (+,0,0)  --open x-->  ⊘
B (−,−,+)  --open z-->  Q (−,−,0)  --open y-->  U (−,0,0)  --open x-->  ⊘
```

**F·S·W** [path DERIVED, gloss MINTED] — F differs from E in exactly one axis
(z), and F's first opening lands on `S = seam(E,F)`: the membrane F *shares
with E*. Read: a settled thing lets go first of the join it holds with its
nearest other, then of its identity axis, then dissolves. The word means
"F approaching E-ness through their shared wall."

**G·O·V** [path DERIVED, gloss MINTED] — G exits through `O = seam(E,G)`,
relaxes onto the +x face V, ends. (That this spells "gov" is an accident of
the lettering, but a telling one: full decidedness relaxing by stages is not
a bad picture of governance dissolving into pragmatics.)

**B·Q·U** [path DERIVED, gloss MINTED] — B exits through `Q = seam(A,B)`,
its wall with A, then through the −x face into the void.

### Finding 1 — every utterance begins by naming a neighbor [DERIVED]

A corner's first step always lands on an edge, and every edge is the seam of
exactly two corners. So the first syllable of any word is *which neighbor you
leave through*. F·S·W and a hypothetical E·S·… share their opening membrane;
that shared exit is a real kinship between words, not coincidence — it
generalizes your own observation that A and E both open into I. Etymology
here is not just "the path"; it is, more sharply, **the sequence of others
you pass through on the way to silence**.

### Finding 2 — the word-space is 48, and that is a syllabary, not a language [DERIVED count, MINTED diagnosis]

A spelling = (corner, ordering of its three axes) = 8 × 3! = **48 valid
words, total**. As defined, the grammar is a closed syllabary: a speaker
stumbles at sentence two, because there is no composition rule — every word
ends at `⊘` and nothing says what may follow.

**Proposal (descent-continuation) [MINTED]:** use the self-similarity you
already have. Globally a spelling must terminate at `⊘`; but locally, *every
glyph is the `⊘` of its own frame* (Core 27, file `04` §3). So let a
traversal that reaches any cell **descend**: re-enter that glyph's own
term-frame at its center and continue spelling inside it — decide outward to
one of its corner-terms, open again, descend again. Termination at the global
`⊘` is the full stop; arrival at a letter plus descent is a comma. **The
period is a comma one level down.** This turns 48 syllables into an infinite,
rule-governed utterance space without adding a single new primitive.
Non-example (what this is *not*): free concatenation "A·I·Y·⊘ H·L·Z·⊘" with
no structural relation between the words — that is a list, not a sentence.

Note this proposal also answers tension 5; see §5.

---

## 2. One letter, fully framed — E, the issuer of the trio

I chose **E** `(+,−,−)` deliberately: file `04` §2 records that S·I·O — the
only three worked glyphs — is *exactly E's request set* ("E's seam-star").
The trio you are holding OPEN is issued by a single unworked corner. Framing
E gives the trio its origin point.

Everything structural below is **DERIVED** (recomputable by
`build_term_frames` in `knoll.py`; I followed its slot order exactly).
Everything semantic is **MINTED by me** and rides as the *occupant layer* of
each slot — see §3 for why I split the two.

**Proposed pivot (center occupant): "emitter."** [MINTED]
The fully-decided point that originates; every one of E's 26 terms must read
as a facet of issuance, or the pivot fails. Non-example: *a relay* — passes
along without having decided anything; E is maximally decided, it originates.
(Resonance, not argument: your own source text's compiler section says the
emitters are where the creole proves itself.)

| d | slot | structural content [DERIVED] | semantic occupant [MINTED unless noted] |
|---|---|---|---|
| (0,0,0) | center | the glyph **E** — Self/void keystone | pivot: **emitter** — the decided origin (OPEN until bdo admits) |
| (−1,0,0) | face | request → **I** (opening x) | *emit-instance* — the facet of E that yields the unit fiber |
| (+1,0,0) | face | decided `x = +` | *tenet x+* — a held decision; why nothing lies that way |
| (0,+1,0) | face | request → **O** (opening y) | *emit-scope* — the facet that yields the enclosing ring |
| (0,−1,0) | face | decided `y = −` | *tenet y−* |
| (0,0,+1) | face | request → **S** (opening z) | *emit-join* — the facet that yields the stitch |
| (0,0,−1) | face | decided `z = −` | *tenet z−* |
| (−1,−1,−1) | corner | fact: kind = corner | settled: E is an origin-kind, not a join-kind |
| (−1,−1,+1) | corner | fact: dim 0 | nothing open: emission only, no reception |
| (−1,+1,−1) | corner | fact: codim 3 | three decisions held at once |
| (−1,+1,+1) | corner | fact: axis · (none) | belongs to no single axis; all three equally |
| (+1,−1,−1) | corner | fact: status PINNED | E's address is quoted, not derived |
| (+1,−1,+1) | corner | fact: capacity 7 / 19 | seven kin in frame, nineteen futures |
| (+1,+1,−1) | corner | fact: wing addr | this frame reads E as a *where* |
| (+1,+1,+1) | corner | fact: home piece **Y · DBR** | the *what* that rests here when solved |
| edge 1 | edge | relation: antipode **D** `(−,+,+)` | *the inverse emitter* — every decision flipped |
| edge 2 | edge | live occupant `@` | whoever sits here now (viewer fills it) |
| edge 3 | edge | OPEN → candidate [MINTED]: *kin-through-I: A* | the neighbor behind the I-membrane |
| edge 4 | edge | OPEN → candidate [MINTED]: *kin-through-S: F* | the neighbor behind the S-membrane |
| edge 5 | edge | OPEN → candidate [MINTED]: *kin-through-O: G* | the neighbor behind the O-membrane |
| edge 6 | edge | OPEN → candidate [MINTED]: *issuer-of(S·I·O)* | E uniquely requests the whole trio |
| edges 7–12 | edge | OPEN | capacity, deliberately unfilled |

Non-examples for the minted edge relations: **kin** — H is not E's kin: it
differs in two axes and shares no seam with E (kinship requires a shared
membrane, not mere co-cornerhood). **issuer-of(S·I·O)** — A is not the
trio's issuer: A requests I,M,Q, which overlaps the trio on I but is not it;
exactly one corner's request-set equals the trio, and it is E.

The kin candidates are honestly **DERIVED-able** (they read straight off the
`seam_of` column), which is why I propose them for permanent edge slots: they
regenerate when the graph changes, which your discipline demands.

---

## 3. Pivot vs. keystone — one contract, two layers, and you already own the move

Answer to question 2: **they are two layers, and the reconciliation is
already in your geometry.** Apply the system's own deepest split — *address
vs. occupant, where vs. what* — to the center slot itself:

- **`center.address` = the glyph itself.** The keystone. DERIVED, invariant,
  never edited. This preserves the empty-center law in its exact sense: the
  keystone adds *zero new information* — it only restates the frame's name.
  Empty of content, full of identity.
- **`center.occupant` = the pivot lens.** MINTED per letter ("emitter" for E,
  your "interface" example for whichever letter earns it), owner-admitted,
  allowed to be OPEN. A frame whose center occupant is OPEN is simply an
  *unsolved frame* — exactly as a scrambled cube is a legal state.

This is option (b) from file `06` §B, but with option (a) demoted to a
**check** rather than an identity: the pivot is *valid* only if each of the
26 terms reads as a facet of it (the lens test — E's table above is built to
pass it). Derivability is the falsifier, not the definition.

The consequence worth flagging: **question 2 and tension 1 are the same
decision at two scales.** If bdo pins the complementarity reading of the two
alphabets (a state is a pairing of where and what; solved = canonical
pairing), then the center contract above is just that reading applied one
level down — local solvedness = pivot admitted. If he refuses it, both fall
together. One pin settles two open seams. [MINTED, and I would call it the
highest-leverage admit in the package.]

---

## 4. The weighting — a chip code a person can run by hand

Per tension 4, every number below wears its status. The claim that *density =
decidedness* is itself an **assumption (MINTED)**, not a measurement; the
geometry only makes it natural.

### Layer 0 — the axis code (structural prior, zero observations) [DERIVED]

Write a glyph as its coordinate, axis by axis, x then y then z, using the
prefix code:

```
open (0)  →  0          one bit
minus (−) →  10         two bits
plus  (+) →  11         two bits
```

So: **a glyph costs 3 bits of skeleton plus 1 extra bit per decision.**

```
glyph kind   code length   example
center ⊘     3 bits        000
face         4 bits        Y (0,0,−) → 0 0 10
edge         5 bits        S (+,−,0) → 11 10 0
corner       6 bits        E (+,−,−) → 11 10 10
```

Three properties, all hand-checkable:

1. **It is a complete prefix code — zero waste.** Kraft sum:
   1·2⁻³ + 6·2⁻⁴ + 12·2⁻⁵ + 8·2⁻⁶ = 0.125 + 0.375 + 0.375 + 0.125 = **1
   exactly**. The implied prior reads off directly: each axis independently
   is open with probability ½, minus ¼, plus ¼. Corners are rarest (1/64
   each), the void commonest (1/8) — your "more decided = denser = costlier"
   gradient, realized exactly, before a single token is observed.
2. **Decoding is by eye.** Read left to right: a leading 0 closes an axis; a
   leading 1 takes one more bit for the sign. Three fields, done.
3. **Spelling is bit-shedding.** [DERIVED, and I think this is the package's
   prettiest unclaimed fact] Each open-step deletes exactly one bit:
   `E → 111010 (6) → S → 11100? no — 11 10 0 (5) → W → 0 10 0 (4) → ⊘ → 000
   (3)`. A word is a 6-5-4-3 staircase; meaning dissolving into the void *is*
   information being shed, one bit per step. The semantics and the coding
   theory are the same picture.

### Layer 1 — chips (usage update that stays legible) [counts MEASURED; update rule MINTED]

Seed every glyph with **chips** proportional to its Layer-0 prior:

```
corner 1 chip · edge 2 chips · face 4 chips · void 8 chips
seed total = 8·1 + 12·2 + 6·4 + 8 = 64 chips
```

Rules a person can run:

1. Every observed use of a glyph adds **one chip** to its row.
2. A glyph's bit-cost is **how many doublings its chips sit below the table
   total** (round up): `bits = ⌈log₂(total ÷ chips)⌉` — but you never need
   the formula: double the glyph's chips until you pass the table total, and
   count the doublings.
3. At zero observations this reproduces Layer 0 exactly (64÷1 → 6 doublings
   for a corner; 64÷8 → 3 for the void). The structural prior and the usage
   table are *one table*, not two systems.

Worked hand-check: after 36 observations, total = 100 chips. Say S was used
14 times: S holds 2+14 = 16 chips. 16 → 32 → 64 → 128: three doublings to
pass 100, so **S costs 3 bits**, down from its structural 5 — and anyone can
see *why* from the tally column alone. (This is a Shannon code over a
Dirichlet-smoothed count; it wastes at most one bit per glyph versus optimal.
If exactness ever matters, build a Huffman tree from the chip column — still
hand-doable at 27 symbols, just tedious.)

### Finding 3 — "probability = density = use" is three things wearing one name [MINTED, you asked]

Yes, it is three things, and the scheme above deliberately keeps them as
three visible columns: **seed** (density — intrinsic decidedness, fixed by
geometry), **tally** (use — empirical, will drift), **code** (probability —
whatever the sum says today). Do not fuse them. Their divergence is the
interesting data: a corner being used far above its density is a seam that
does not close, and by your own doctrine that is a finding, not an error to
normalize away. Per tension 4: the seed column is DERIVED, the tally is
MEASURED, the equivalence claim is ASSUMED, and any seam-weight a model
proposes is MODEL-GUESSED and must say so. If built, the table is an
admitted record signed `--by`, never a constant in code — agreed, and the
chip format is designed so the signed artifact is *literally readable*.

---

## 5. Coherence — where it holds, where a speaker stumbles first

**It is coherent** as an ontological/epistemological/etymological system in
the specific sense that its three lenses are not decoration: the pairing
(where/what) really is an ontology of identity; the provenance gates really
are an epistemology of admission; and the path-as-derivation really is an
etymology — Finding 1 sharpens it to *lineage through neighbors*. The
empty-center law and the derivation discipline (re-arranging is re-knolling)
are the two load-bearing walls, and both held under everything I tried.

Where it is underspecified, in the order a user hits the wall:

1. **A speaker stumbles at sentence two.** 48 words, no composition rule
   (Finding 2). Descent-continuation (§1) is my proposed fix; it also gives
   the recursion a principled tail — next point.
2. **The recursion tail: make it traversal-driven.** [MINTED answer to
   tension 5] The structure should be *potentially* infinite and *actually*
   finite: a glyph's sub-frame instantiates only when an admitted utterance
   descends into it. Depth is not a property of the geometry; it is a
   property of the admission log. Turtles all the way down in potential,
   gated in actual — which matches D-4 (self-extension proposes, the owner
   admits) exactly. No base-3 descent schedule (27→9→3→1) is needed, and the
   source's undefined Hypothesis B can stay undefined: descent is on demand,
   not on counts.
3. **A speaker can say *where* but not *what*.** The pairing thesis is the
   ontology's hinge, yet the language has no notation for a pairing. You
   cannot currently utter "piece Y sits at address E." Smallest fix
   [MINTED]: a pairing mark, e.g. `E[Y]` — occupant in brackets at its
   address — so that a *state* becomes spellable, and the solved cube
   becomes the canonical sentence.
4. **The non-example rule is doctrine but not machinery.** The grip ledger
   carries falsifiers; term-frame slots do not, and nothing in `knoll.py`
   fails when a MINTED term lacks one. A builder stumbles here first: the
   generator will happily knoll a hole as if it were a grip. Fix: a check in
   the generator — MINTED occupant without a non-example renders as OPEN,
   whatever the author wrote.
5. **Smallest relation set that makes a frame "complete enough to speak"**
   (your question in `06` §C): four — **seam, request, antipode, pairing
   (occupant)**. With those, every slot the spelling grammar touches is
   defined; trio-membership and everything else is lexicon, endlessly
   extensible by design (that is what the OPEN edge slots are *for*).
   Completeness criterion [MINTED]: a frame is speakable when its faces are
   fully derived (automatic), its center occupant is admitted **or
   explicitly OPEN**, and at least one edge relation carries a non-example.
6. **One wording to pin eventually:** "etymological" is doing double duty —
   generator-lineage of units (etymontoken) and path-as-derivation of words.
   They coincide here, which is elegant, but the coincidence is a claim;
   pin it or split the term.

---

## 6. Proposals and findings, consolidated

| # | item | status |
|---|---|---|
| P1 | Spellings F·S·W·⊘, G·O·V·⊘, B·Q·U·⊘ | paths DERIVED, glosses MINTED |
| P2 | First-syllable = exit-membrane; etymology as lineage-through-neighbors | DERIVED |
| P3 | Word-space is exactly 48; grammar as defined is a syllabary | DERIVED count, MINTED diagnosis |
| P4 | Descent-continuation: "the period is a comma one level down" | MINTED |
| P5 | E's term-frame, 27 slots, pivot "emitter" | structure DERIVED, occupants MINTED, pivot OPEN pending admit |
| P6 | Center contract: `center.address` = keystone, `center.occupant` = pivot; lens test as falsifier | MINTED |
| P7 | Question 2 ≡ tension 1 at two scales; one pin settles both | MINTED |
| P8 | Axis code: 3 bits + 1 per decision; complete prefix code, Kraft sum exactly 1 | DERIVED |
| P9 | Spelling is bit-shedding: one bit per open-step, 6→5→4→3 | DERIVED |
| P10 | Chip scheme: seed 1/2/4/8, +1 per use, bits = doublings to table total | seed DERIVED, counts MEASURED, rule MINTED |
| P11 | Probability, density, use are three columns; divergence is data | MINTED |
| P12 | Recursion tail: traversal-driven instantiation, depth = admission log | MINTED |
| P13 | Pairing notation `E[Y]` so states are utterable | MINTED |
| P14 | Generator should demote falsifier-less MINTED occupants to OPEN | MINTED |
| P15 | Minimal speakable relation set: seam, request, antipode, pairing | MINTED |

Aimed at the seams, as requested. Load back what survives the gate; refuse
the rest with receipts — I would rather be refused with a reason than
admitted on charm.
