# Landing map — where the work lands

*What this is: every live proposal from this thread, located on disk,
sequenced by dependency. Three kinds of work, kept apart: **PINS** (owner
decisions — no build until stamped), **BUILDS** (generator/registry/viewer —
Claude Code sessions through the pens), **MEASURES** (benchmarks — runnable
scripts, results come home as admitted records). Artifacts already produced
in this thread are listed with their landing path; chat prose with no
artifact is flagged as such.*

---

## 0. The pin batch — six owner decisions, most of the map hangs on them

| # | pin | what it unblocks | cost to decide |
|---|---|---|---|
| PIN-1 | **Complementarity** — address/occupant pairing as the ontology (knolling finding `seam.lettering-collision`, held MINTED) | pivot/keystone contract (same decision one level down); pairing notation | one stamp — the reading is already written |
| PIN-2 | **Placement law** — sit/act/read rubric, or another derivation | the entire placement pass; SC measurement; falsifier goes live | one sentence; pilot on 5 S-words first |
| PIN-3 | **I/S/O ≅ −/0/+** — the trio as the sign alphabet | spellable addresses (`A = III`, `⊘ = SSS`); register/axis question | falsifiable: spell 5 addresses aloud, keep or kill |
| PIN-4 | **Glyph = word; letter = lens** — into the grip ledger with non-examples (glyph, lens, frame, basin, escape) | every doc stops equivocating; generator can type them | ledger entries drafted below, stamp or amend |
| PIN-5 | **Utterance canon** — closure order (boundary-first/self-last) + descent-continuation as the composition grammar | syllabary v1; multi-frame utterances | provisional canon already running in viewer; confirm or replace |
| PIN-6 | **NON→NULL conversion standard** — what proves a slot empty | escape pricing; X/Y/Z frames become honest | pick one: exhaustive scan / n failed passes / owner stamp |

PIN-1 and PIN-2 are the load-bearing two. Everything in waves 2+ assumes them.

---

## 1. Artifacts from this thread, and where each lands

| artifact (in hand) | lands at | via |
|---|---|---|
| review memo (15 proposals) | `exports/` return → re-verified → admitted per item | the done-line 0016 flow (external verdict comes home) |
| `recursive-pilish-basin-v0.md` (669 glyphs, 60 OPEN, v1 composition contract) | `language/basin.md` + parsed into `glyphs/registry.json` as surveyed lexicon | write pen; generator parses it live like the grip ledger |
| viewer edits (ontabet panel; closure/star inspector section) | **re-land through `knoll.py`'s viewer template**, not as hand-edits to the emitted file | PR pen; the hand-edited copy is the spec, the template port is the build |
| chip code + escape scheme (chat prose, no artifact) | `language/weights.md` (new stratum) + per-frame tables in registry | needs BUILD-2 schema first |
| incidence laws (computed, receipts in thread) | `knoll.py`: emit closure/star per cell into registry + knolling.md §;  the laws become DERIVED columns | small generator change, no pin needed |
| rosetta rows (math column draft: corners=monomials, center=Duality) | `language/registers.md` (new stratum: cross-register table per cell) | blocked on nothing; survey work |

## 2. Builds, in dependency order

**Wave 1 — no pins required (start now):**
- BUILD-1 `knoll.py`: emit closure/star fans + the two laws per cell; demote
  falsifier-less MINTED terms to OPEN (the doctrine→machinery gap).
- BUILD-2 registry schema growth: per-cell `placements{lens: word, status}`,
  `attestations[donor, ref]`, per-frame `chips{word: n}` + `escape`,
  typed empties `{NULL|NON, constraint, unlock}`, frame-level `sc` field.
- BUILD-3 port the two viewer features into the injection template; add
  donors + SC columns to the ontabet panel (render OPEN until data exists).
- BUILD-4 lexifier-density column: count fill-rate per letter from the basin,
  admit as the first measured weight donor (signed record, not constant).

**Wave 2 — after PIN-2 (placement):**
- BUILD-5 placement pass: S, I, O lists onto their cubes by the law; every
  placement runs the closure falsifier; refusals knolled as findings.
- BUILD-6 viewer: placed words on facelets in the local-cube inspector;
  falsifier verdict rendered per cell.

**Wave 3 — after PIN-5 (utterance canon):**
- BUILD-7 syllabary v1 in the panel: graded utterances (3^dim words),
  descent-continuation notation; pairing notation `E[Y]` if PIN-1 lands.

## 3. Measures — each result returns as a signed record

- MEAS-1 **leakage pre-test** (runnable today, no pins): bagged-arm cloze on
  S/I/O lists — if the pivot is recoverable from the bag alone, the frame
  leaks morphologically. Gates whether SC results mean anything.
- MEAS-2 **embedding coherence** (runnable today): 81 S/I/O words through an
  embedding model; composition sums + antipode structure vs shuffled control.
  First contact between authored and learned geometry.
- MEAS-3 **structure coefficient** (after BUILD-5): placed/bagged/scrambled
  cloze per frame; SC = conditional-vs-marginal bits saved. The
  cube-vs-random distinguisher, per frame, into the registry's `sc` field.
- MEAS-4 **second-pass attestation** (anytime): re-run the recursive-pilish
  process via envoy on a foreign family (Codex is already admitted as guest);
  diff against the basin; convergences become attestations, divergences
  become survey targets.

## 4. Who does what

- **bdo:** the six pins (§0); steers via epics, not tickets — this map is
  one epic ("the ontabet speaks") with four waves as its arc.
- **Claude Code sessions:** BUILD-1…7 through the pens, stamped increments.
- **This surface (chat):** prose→spec conversion done; remaining use is
  pin deliberation and MEAS design review.
- **Foreign families (envoy):** MEAS-4 attestation passes; memo-style
  verdicts home through the 0016 route.

## 5. The one-line sequence

Stamp PIN-1/PIN-2 → Wave 1 builds land in parallel → place S/I/O → run
MEAS-1/2/3 → SC numbers decide whether the cube is a cube → then, and only
then, spend on A–Z placement at scale.

---

## 6. Session delta — executed since this map was drafted

| item | was | now |
|---|---|---|
| PIN-2 evidence | "pilot on 5 S-words first" | **full S-frame placed** (27/27, zero collisions, census 8/12/6/1 emergent, Seam derives to center) — `s-frame-placements-v0.json` |
| falsifier | designed | **fired once**: Span refused (candidate swap with Semantics), 5/6 faces pass |
| PIN-3 evidence | "spell 5 addresses" | done: A=III, E=OII, S=OIS, Y=SSI, ⊘=SSS — all sayable |
| placement law | one law assumed | **two laws, per register**: rubric (concept frames) + autological (parent/basis frame), with measured precedence (self-description > duality) |
| rubric calibration | no instrument | 9/11 kind agreement on definitional anchors, Origin cell-level bullseye; contaminated-scorer caveat logged |
| ⊘'s frame | conflated with basis vocabulary | **level-split corrected**: parent frame (cube components) vs interstitial frame (27 distinctions of between-ness); Cant derived as edge(Centroid, Barycenter); descent law minted |
| new pin | — | **PIN-7: the descent law** — center names the undistinguished; descent mints distinctions; collisions signal needed descent, not dedup |
| new measure | — | **MEAS-5: frame-overlap test** — draft S's child-frame, diff against the interstitial frame; overlap = a seam between frames |

Pin batch is now seven, every one carrying a worked instance. Remaining
honestly unexecuted: I/O placements (one session), 11 interstitial edge
pole-pairs, all uncontaminated measurement (MEAS-1/2/3 — needs Claude Code
or envoy), and every stamp.
