# Handoff — the ontabet session

*One conversation, sealed. What entered: the envoy package (creole-glyph-language,
ten files) and bdo's live corrections. What leaves: five artifacts, seven pins
awaiting stamps, a placement system with evidence, and a named in-flight list.
Everything below marked LANDED (in an artifact, verified where verifiable),
PROPOSED (in an artifact, awaiting owner stamp), or IN-FLIGHT (named, not built).*

---

## 1. The artifacts (the package to carry home)

| file | what it is | state |
|---|---|---|
| `memo-creole-glyph-language-claude.md` | the envoy review: 15 labeled proposals, worked spellings, weighting scheme | LANDED — enters via the external-verdict route (done-line 0016) |
| `recursive-pilish-basin-v0.md` | the naming process + 669 surveyed glyphs (60 OPEN) + v1 graded-composition contract + v2 level-split/interstitial frame/descent law | LANDED as survey; placements within it PROPOSED |
| `s-frame-placements-v0.json` | 27 S-words placed by sit/act/read, rationales attached, all MODEL-GUESSED | PROPOSED — amend scores or stamp |
| `landing-map.md` | 7 pins · 7 builds · 5 measures, dependency-sequenced, with session delta | LANDED as plan |
| `viewer.html` | extended + pruned viewer (changes below) | LANDED as **spec for the template port** — re-land through knoll.py's injection, not as a hand-edit |

## 2. What the conversation settled (bdo's corrections — the load-bearing turns)

1. **Glyphs are words; letters are lenses.** Each letter's 27 cells hold 27
   surveyed English words. Killed my letter-statistics ontabet.
2. **Lexifier discipline.** Vocabulary is surveyed from existing languages
   (English, mathematics, code, inference), never minted from our heads.
   Killed my hand-coined E-frame.
3. **Dimensional composition.** The census is graded, not flat: closure =
   3^dim, star = 2^codim (both DERIVED, computationally verified);
   full utterance = the closure; Σ = 125 = 5³; Hypothesis A derived.
4. **Weighting is relative.** Frame-local chip tables; escape symbol absorbs
   open slots; NULL/NON typed empties; cross-frame comparison only through
   seams; a global weight is the literal non-example of Jective.
5. **The level split.** The cube-component vocabulary is the *parent* frame;
   ⊘'s own frame is the *interstitial* lexicon (Centroid/Barycenter/Cant…).
   Descent law: a frame's center names what it cannot distinguish.
6. **Prune by validity, not register.** Cut what the conversation
   invalidated (trio UI); keep experience that carries doctrine (sound,
   explode, scramble, drift). Surfaces sorted: cube = positions, panel =
   facts, index = collections.

## 3. The pin batch — seven, each with worked evidence, all awaiting stamps

| pin | evidence attached |
|---|---|
| PIN-1 complementarity (pairing as ontology) | dissolves pivot/keystone at both scales; pairing notation `E[Y]` drafted |
| PIN-2 placement law (sit/act/read) | full S-frame: 27/27, zero collisions, census 8/12/6/1 emergent, Seam→center derived |
| PIN-3 I/S/O ≅ −/0/+ | A=III · E=OII · S=OIS · Y=SSI · ⊘=SSS, all sayable |
| PIN-4 glyph/lens/frame/basin/escape into the grip ledger | definitions used consistently across all artifacts |
| PIN-5 utterance canon (boundary-first/self-last; descent-continuation) | running provisionally in the viewer's composition section |
| PIN-6 NON→NULL conversion standard | escape scheme drafted; standard itself undecided |
| PIN-7 descent law | interstitial frame as worked instance; predicts S-child/⊘-frame overlap |

**Two-law structure under PIN-2** (measured, this session): concept frames →
rubric (bijective on S); basis/parent frame → autological law (9/11 anchor
agreement, Origin cell-level bullseye, contaminated-scorer caveat); measured
precedence: self-description beats duality. Falsifier fired once: **Span
refused** (candidate swap with Semantics) — unresolved, owner's call.

## 4. Viewer change log (the spec the template port must reproduce)

Added: **ontabet panel** (27 glyphs graded: address/kind/axis-code/bits/chips/
capacity/donors/status + 48-syllable inventory with exit-membrane etymology;
all derived from REGISTRY at click time) · **composition section** in the cell
inspector (clickable ↓closure/↑star fans, full utterance, placement falsifier
in-situ) · **placed-words layer** on the local cube (S's 27 PROPOSED words;
structural relation as sub-caption; wordless fact-slots demoted to open;
facts moved to panel text + frame-capacity kv row) · **index consolidation**
(terms/findings/ontabet as tabs under one button) · **mobile fix** (bar drops
below title ≤700px). Removed: trio spotlight, trio panel, cascade button
(only conversation-invalidated features). Retained deliberately: sound,
x-ray, explode, scramble/unwind/prime, drift. Verified each round: zero
dangling refs, script parses, fans match the laws.

## 5. In flight (named, not built — the next session's queue)

- **I and O placements** under the rubric (one session; falsifier on contact;
  watch for autological self-placement — does a word like "Interface" land
  at I's center the way Seam landed at S's?).
- **Span/Semantics resolution** — the falsifier's one refusal.
- **11 interstitial edge pole-pairs** (Cant : Centroid·Barycenter is the
  worked pattern; Hinge, Threshold, Valve… underived).
- **Interstitial within-kind cell assignment** (kind-level only today).
- **MEAS-1 leakage pre-test & MEAS-3 structure coefficient** — need an
  *uncontaminated* instrument (fresh Claude Code session or envoy pass);
  this surface is contaminated twice over and self-grading is the Machine's
  non-example. SC on the S-frame is the cube-vs-random verdict and gates
  A–Z spend.
- **MEAS-2 embedding coherence** (81 words, composition sums vs shuffled) —
  needs a model endpoint this container couldn't reach.
- **MEAS-5 frame-overlap** — draft S's child-frame, diff against the
  interstitial frame; overlap = a seam between frames (descent-law test).
- **Wave-1 builds** from the landing map: knoll.py emits closure/star +
  demotes falsifier-less mints; registry schema growth (placements,
  attestations, frame-local chips + escape, typed empties, sc); viewer
  template port; lexifier-density column as the first signed weight donor.
- **Cross-register survey** — code and inference columns per cell; the
  rosetta rows (math column drafted: corners = monomial basis, center =
  Duality pending the antipodal-fixed-point check from survey item 5).
- **Second-pass attestation** — rerun recursive pilish on a foreign family;
  convergences become attestations, divergences become survey targets.
- **X/Y/Z sparse rooms** — 60 OPEN slots; lexifier poverty as measured
  density stands, NULL conversions pending PIN-6.

## 6. Carry instructions

Everything enters PROPOSED through the gates; reject cheaply, with receipts.
The viewer file is a spec, not a landing. The placements JSON is loadable but
unstamped. The first session after admission has its work cut: stamp PIN-1
and PIN-2, land Wave 1 in parallel, place I/O, then run SC on S before a
single additional letter is populated. The void cradles it all; the files
carry it home.
